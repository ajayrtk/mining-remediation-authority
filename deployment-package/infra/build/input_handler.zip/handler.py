# Lambda triggered by S3 upload - creates DynamoDB records and launches ECS task

import json
import logging
import os
import urllib.parse
from datetime import datetime
from uuid import uuid4

import boto3
from botocore.exceptions import ClientError

# AWS service clients
dynamo = boto3.client("dynamodb")
lambda_client = boto3.client("lambda")
s3_client = boto3.client("s3")
ecs_client = boto3.client("ecs")

# Configuration from environment variables
# These are set by Terraform when deploying the Lambda
TABLE_NAME = os.getenv("JOBS_TABLE_NAME")  # DynamoDB table for tracking jobs
MAPS_TABLE_NAME = os.getenv("MAPS_TABLE_NAME")  # DynamoDB table for individual maps
S3_COPY_FUNCTION = os.getenv("S3_COPY_FUNCTION_NAME")  # Fallback Lambda processor
ECS_CLUSTER = os.getenv("ECS_CLUSTER")  # ECS cluster name
ECS_TASK_DEFINITION = os.getenv("ECS_TASK_DEFINITION")  # Task definition for processing
ECS_SUBNETS = os.getenv("ECS_SUBNETS", "").split(",")  # VPC subnets for ECS tasks
ECS_SECURITY_GROUP = os.getenv("ECS_SECURITY_GROUP")  # Security group for ECS tasks
PROJECT = os.getenv("PROJECT_NAME", "mra-mines")  # Project name for tagging


# Helper function to generate ISO 8601 timestamps for DynamoDB
def iso_timestamp() -> str:
    return datetime.utcnow().isoformat(timespec="milliseconds") + "Z"


def validate_filename(filename: str) -> tuple[bool, str, str, str]:
    """Validate map filename format: SeamID_SheetNumber.zip (mirrors frontend validation)"""
    import re

    # Remove file extension
    name_without_ext = re.sub(r'\.(zip|jpg|jpeg|tif|tiff)$', '', filename, flags=re.IGNORECASE)

    # Check for mandatory underscore
    if '_' not in name_without_ext:
        return False, '', '', f"Missing mandatory underscore separator. Expected format: SeamID_SheetNumber.zip (e.g., '16516_433857.zip')"

    # Look for 6-digit sheet number pattern in two formats:
    # Format 1: XX_XXXX (2 digits + separator + 4 digits)
    # Format 2: XXXXXX (6 consecutive digits)
    # Use regex with negative lookbehind to ensure pattern isn't preceded by digits
    sheet_number_pattern = r'(?<!\d)(\d{2}[-\s_]\d{4}|\d{6})'
    match = re.search(sheet_number_pattern, name_without_ext)

    if not match:
        # No valid sheet number pattern found
        all_digits = re.sub(r'\D', '', name_without_ext)
        if len(all_digits) == 0:
            return False, '', '', f"No digits found. Sheet number must be exactly 6 digits in format XXXXXX or XX_XXXX."
        elif len(all_digits) < 6:
            return False, '', '', f"Sheet number must be exactly 6 digits, found {len(all_digits)} digits. Expected format: SeamID_SheetNumber.zip (e.g., '16516_433857.zip' or '43_43_3857.zip')"
        else:
            return False, '', '', f"Found {len(all_digits)} digits but sheet number format is incorrect. Expected 6 digits in format XXXXXX or XX_XXXX (e.g., '433857' or '43_3857')."

    # Extract sheet number (remove any separators to get 6 digits)
    sheet_number_raw = match.group(1)
    sheet_number = re.sub(r'\D', '', sheet_number_raw)

    # Everything before the sheet number pattern is the seam ID
    sheet_number_start_index = match.start()
    seam_id = name_without_ext[:sheet_number_start_index]

    # Validate seam ID exists and ends with underscore
    if not seam_id or not seam_id.endswith('_'):
        return False, '', '', f"Missing mandatory seam ID before sheet number. Expected format: SeamID_SheetNumber.zip (e.g., '16516_433857.zip')"

    # Remove trailing underscore from seam ID
    seam_id_clean = seam_id[:-1]

    # Validate seam ID is not empty after removing underscore
    if not seam_id_clean or seam_id_clean.strip() == '':
        return False, '', '', f"Missing mandatory seam ID before underscore. Expected format: SeamID_SheetNumber.zip (e.g., '16516_433857.zip')"

    # Validate seam ID contains only alphanumeric characters
    if not re.match(r'^[a-zA-Z0-9]+$', seam_id_clean):
        return False, seam_id_clean, '', f"Invalid seam ID '{seam_id_clean}'. Seam ID must contain only letters and numbers."

    return True, seam_id_clean, sheet_number, ''


def get_s3_metadata(bucket: str, key: str) -> dict:
    """Retrieve metadata from the uploaded S3 object."""
    try:
        response = s3_client.head_object(Bucket=bucket, Key=key)
        metadata = response.get("Metadata", {})

        # Log warning if metadata is empty - could indicate issue with presigned URL generation
        if not metadata:
            logging.warning(
                f"S3 object has no metadata - file may not have been uploaded via presigned URL",
                extra={"bucket": bucket, "key": key}
            )

        return metadata
    except ClientError as exc:
        error_code = exc.response.get("Error", {}).get("Code", "Unknown")

        if error_code == "404" or error_code == "NoSuchKey":
            logging.error(
                f"S3 object not found: {bucket}/{key}",
                extra={"bucket": bucket, "key": key, "error_code": error_code}
            )
            raise  # Re-raise to let caller handle missing object
        elif error_code == "403" or error_code == "AccessDenied":
            logging.error(
                f"Access denied to S3 object: {bucket}/{key}",
                extra={"bucket": bucket, "key": key, "error_code": error_code}
            )
            raise  # Re-raise to let caller handle permission issue
        else:
            logging.exception(
                "Unexpected error retrieving S3 metadata",
                extra={"bucket": bucket, "key": key, "error_code": error_code}
            )
            raise  # Re-raise to let caller handle unexpected errors


def create_map_entry(map_id: str, map_name: str, owner_email: str, owner_name: str | None, owner_username: str | None, size_bytes: int, timestamp: str, job_id: str) -> None:
    """Create a MAP entry in the MAPS table linked to a job."""
    if not MAPS_TABLE_NAME:
        logging.warning("MAPS_TABLE_NAME not configured, skipping MAP creation")
        return

    try:
        # Try to create a new map entry
        # The ConditionExpression prevents duplicates by checking if mapId/mapName combo exists
        item = {
            "mapId": {"S": map_id},  # Hash-based ID from file content
            "mapName": {"S": map_name},  # Sanitized filename
            "ownerEmail": {"S": owner_email},
            "createdAt": {"S": timestamp},
            "inputSizeBytes": {"N": str(size_bytes)},
            "mapVersion": {"N": "1"},
            "jobId": {"S": job_id},
            "status": {"S": "QUEUED"}  # Start in QUEUED state
        }

        # Add owner name and username only if provided
        if owner_name:
            item["ownerName"] = {"S": owner_name}
        if owner_username:
            item["ownerUsername"] = {"S": owner_username}

        dynamo.put_item(
            TableName=MAPS_TABLE_NAME,
            Item=item,
            ConditionExpression="attribute_not_exists(mapId) AND attribute_not_exists(mapName)"
        )
        logging.info(f"Created MAP entry: {map_id} / {map_name} linked to job {job_id} with status QUEUED")
    except ClientError as exc:
        # If the map already exists, this might be a retry scenario
        # The frontend checks for FAILED maps and allows users to re-upload them
        error_code = exc.response.get("Error", {}).get("Code", "")
        if error_code == "ConditionalCheckFailedException":
            logging.info(f"MAP entry already exists: {map_id} / {map_name}, updating for retry")
            # Update the existing map for retry:
            # 1. Reset status to QUEUED
            # 2. Link to new jobId
            # 3. Increment retry counter
            # 4. Clear old error message
            try:
                dynamo.update_item(
                    TableName=MAPS_TABLE_NAME,
                    Key={
                        "mapId": {"S": map_id},
                        "mapName": {"S": map_name}
                    },
                    UpdateExpression="SET #status = :status, jobId = :jobId, updatedAt = :updated, #retry = if_not_exists(#retry, :zero) + :inc REMOVE errorMessage",
                    ExpressionAttributeNames={
                        "#status": "status",  # Reserved word
                        "#retry": "retryCount"
                    },
                    ExpressionAttributeValues={
                        ":status": {"S": "QUEUED"},
                        ":jobId": {"S": job_id},
                        ":updated": {"S": timestamp},
                        ":inc": {"N": "1"},  # Increment retry count
                        ":zero": {"N": "0"}  # Start at 0 if retryCount doesn't exist
                    }
                )
                logging.info(f"Updated MAP entry for retry: {map_id} / {map_name}, reset to QUEUED")
            except ClientError as update_exc:
                logging.exception("Failed to update MAP entry for retry", extra={"mapId": map_id, "mapName": map_name})
        else:
            logging.exception("Failed to create MAP entry", extra={"mapId": map_id, "mapName": map_name})


def create_or_get_job(job_id: str, submitted_by: str, timestamp: str, batch_size: int) -> bool:
    """Create job entry if it doesn't exist. Returns True if created."""
    if not TABLE_NAME:
        return False

    try:
        # Try to create a new job record
        # For batch uploads, all files share the same jobId (generated by frontend)
        # So we only create the job once, even if multiple Lambdas are triggered
        dynamo.put_item(
            TableName=TABLE_NAME,
            Item={
                "jobId": {"S": job_id},
                "submittedBy": {"S": submitted_by},
                "status": {"S": "QUEUED"},
                "createdAt": {"S": timestamp},
                "notificationStatus": {"S": "PENDING"},
                "attemptCount": {"N": "0"},
                "mapSource": {"S": "USER_UPLOAD"},
                "batchSize": {"N": str(batch_size)},  # How many files in this batch
                "processedCount": {"N": "0"},  # How many succeeded
                "failedCount": {"N": "0"}  # How many failed
            },
            ConditionExpression="attribute_not_exists(jobId)",  # Only create if doesn't exist
        )
        logging.info(f"Created job {job_id} for batch of {batch_size} files")
        return True
    except ClientError as exc:
        error_code = exc.response.get("Error", {}).get("Code", "")
        if error_code == "ConditionalCheckFailedException":
            # Job already exists - this is normal for batch uploads
            # Another Lambda invocation already created it
            logging.info(f"Job {job_id} already exists")
            return False
        else:
            logging.exception("Failed to create job", extra={"jobId": job_id})
            raise


def mark_failed(job_id: str, reason: str) -> None:
    """Mark a job as FAILED in DynamoDB."""
    if not (TABLE_NAME and job_id):
        return

    try:
        dynamo.update_item(
            TableName=TABLE_NAME,
            Key={"jobId": {"S": job_id}},
            UpdateExpression="SET #status = :failed",
            ExpressionAttributeNames={"#status": "status"},
            ExpressionAttributeValues={
                ":failed": {"S": "FAILED"}
            },
        )
    except ClientError:
        logging.exception("Failed to mark job as failed", extra={"jobId": job_id})


def launch_ecs_task(job_id: str, map_id: str, map_name: str, bucket: str, key: str) -> tuple[bool, str | None]:
    """Launch ECS Fargate task to process the file."""
    # Make sure we have all the ECS config we need
    if not all([ECS_CLUSTER, ECS_TASK_DEFINITION, ECS_SUBNETS, ECS_SECURITY_GROUP]):
        logging.warning("ECS configuration incomplete, skipping ECS task launch")
        return False, None

    try:
        # Launch a new Fargate task
        # We pass the jobId, mapId, and S3 key as environment variables
        # The processor container reads these and knows what to process
        response = ecs_client.run_task(
            cluster=ECS_CLUSTER,
            taskDefinition=ECS_TASK_DEFINITION,
            launchType="FARGATE",  # Serverless - no need to manage EC2 instances
            networkConfiguration={
                "awsvpcConfiguration": {
                    "subnets": ECS_SUBNETS,
                    "securityGroups": [ECS_SECURITY_GROUP],
                    "assignPublicIp": "ENABLED"  # Needed to pull Docker image and access S3
                }
            },
            overrides={
                "containerOverrides": [
                    {
                        "name": "processor",  # Container name from task definition
                        "environment": [
                            {"name": "JOB_ID", "value": job_id},
                            {"name": "MAP_ID", "value": map_id},
                            {"name": "INPUT_KEY", "value": key},
                            {"name": "MAP_NAME", "value": map_name}  # Pass map_name explicitly
                        ]
                    }
                ]
            }
        )

        # Check for launch failures
        failures = response.get("failures", [])
        if failures:
            failure_reasons = [f"{f.get('arn', 'unknown')}: {f.get('reason', 'unknown')}" for f in failures]
            logging.error(f"ECS task launch failures for job {job_id}: {', '.join(failure_reasons)}")
            return False, None

        # Validate that task was actually launched
        tasks = response.get("tasks", [])
        if not tasks:
            logging.error(f"No ECS tasks launched for job {job_id} - empty tasks array")
            return False, None

        task_arn = tasks[0]["taskArn"]
        logging.info(f"Successfully launched ECS task: {task_arn} for job {job_id}")
        return True, task_arn

    except ClientError as exc:
        logging.exception("Failed to launch ECS task", extra={"job_id": job_id, "error": str(exc)})
        return False, None


def validate_s3_input_event(event: dict) -> bool:
    """Validate S3 input event structure."""
    if not isinstance(event, dict):
        raise ValueError(f"Event must be a dict, got {type(event).__name__}")

    if "Records" not in event:
        raise ValueError("Event missing 'Records' field")

    if not isinstance(event["Records"], list):
        raise ValueError("Records must be a list")

    if len(event["Records"]) == 0:
        raise ValueError("Records list is empty")

    return True


def validate_s3_input_record(record: dict) -> tuple[str, str, int]:
    """Validate and extract S3 bucket, key, and size from event record."""
    if not isinstance(record, dict):
        raise ValueError(f"Record must be a dict, got {type(record).__name__}")

    # Check nested structure
    if "s3" not in record:
        raise ValueError("Record missing 's3' field")

    s3_data = record["s3"]
    if not isinstance(s3_data, dict):
        raise ValueError("s3 field must be a dict")

    if "bucket" not in s3_data or "object" not in s3_data:
        raise ValueError("s3 record missing 'bucket' or 'object' field")

    if not isinstance(s3_data["bucket"], dict):
        raise ValueError("bucket field must be a dict")

    if not isinstance(s3_data["object"], dict):
        raise ValueError("object field must be a dict")

    if "name" not in s3_data["bucket"]:
        raise ValueError("bucket missing 'name' field")

    if "key" not in s3_data["object"]:
        raise ValueError("object missing 'key' field")

    bucket = urllib.parse.unquote_plus(s3_data["bucket"]["name"])
    key = urllib.parse.unquote_plus(s3_data["object"]["key"])
    size_bytes = s3_data["object"].get("size", 0)

    if not bucket or not key:
        raise ValueError("bucket name and object key must be non-empty")

    if not isinstance(size_bytes, int) or size_bytes < 0:
        raise ValueError(f"size must be a non-negative integer, got {size_bytes}")

    return bucket, key, size_bytes


def lambda_handler(event, _context):
    """Main Lambda handler - triggered by S3 upload events."""
    # Basic config check - we need these to function
    if not TABLE_NAME or not S3_COPY_FUNCTION:
        raise RuntimeError("Missing JOBS_TABLE_NAME or S3_COPY_FUNCTION_NAME environment variables")

    # Validate event structure
    try:
        validate_s3_input_event(event)
    except ValueError as e:
        logging.error(f"Invalid event structure: {e}", extra={"event": str(event)[:1000]})
        return {"statusCode": 400, "body": f"Invalid event structure: {str(e)}"}

    records = []

    # Process each S3 event record (usually just one, but could be multiple)
    for record in event.get("Records", []):
        try:
            # Validate and extract S3 information
            bucket, key, size_bytes = validate_s3_input_record(record)
        except ValueError as e:
            logging.error(f"Invalid S3 record: {e}", extra={"record": str(record)[:500]})
            continue

        timestamp = iso_timestamp()

        # Extract just the filename (no path)
        map_name = key.split('/')[-1] if '/' in key else key

        # Validate filename format - catches files that bypass frontend validation
        # This is a critical security check for direct S3 uploads
        is_valid, seam_id, sheet_number, error_msg = validate_filename(map_name)
        if not is_valid:
            logging.error(f"Invalid filename format: {map_name} - {error_msg}")

            # Get metadata to create proper tracking records even for invalid files
            try:
                metadata = get_s3_metadata(bucket, key)
            except ClientError as e:
                error_code = e.response.get("Error", {}).get("Code", "Unknown")
                logging.error(
                    f"Cannot process invalid file - metadata retrieval failed: {bucket}/{key}",
                    extra={"error_code": error_code, "map_name": map_name}
                )
                # Skip this file - can't track it without metadata
                continue

            submitted_by = metadata.get("submittedby", "system")
            owner_name = metadata.get("ownername")  # Display name from Cognito
            owner_username = metadata.get("ownerusername")  # Username from Cognito
            map_id = metadata.get("mapid", f"map_{uuid4().hex[:12]}")
            job_id = metadata.get("jobid", f"JobId-{str(uuid4())}")

            # Parse batch size with error handling
            try:
                batch_size = int(metadata.get("batchsize", "1"))
            except (ValueError, TypeError):
                logging.warning(f"Invalid batchsize in metadata for {key}, defaulting to 1")
                batch_size = 1

            # Create/get job record
            try:
                create_or_get_job(job_id, submitted_by, timestamp, batch_size)
            except ClientError:
                logging.exception("Failed to create/get job record for invalid file")

            # Create MAP entry with FAILED status and validation error
            if MAPS_TABLE_NAME:
                try:
                    failed_item = {
                        "mapId": {"S": map_id},
                        "mapName": {"S": map_name},
                        "ownerEmail": {"S": submitted_by},
                        "createdAt": {"S": timestamp},
                        "inputSizeBytes": {"N": str(size_bytes)},
                        "mapVersion": {"N": "1"},
                        "jobId": {"S": job_id},
                        "status": {"S": "FAILED"},
                        "errorMessage": {"S": f"Invalid filename format: {error_msg}"}
                    }
                    # Add owner name and username only if provided
                    if owner_name:
                        failed_item["ownerName"] = {"S": owner_name}
                    if owner_username:
                        failed_item["ownerUsername"] = {"S": owner_username}

                    dynamo.put_item(
                        TableName=MAPS_TABLE_NAME,
                        Item=failed_item
                    )
                    logging.info(f"Created FAILED MAP entry for invalid filename: {map_name}")
                except ClientError:
                    logging.exception(f"Failed to create MAP entry for invalid file: {map_name}")

            # Record the failure and skip processing
            records.append({
                "jobId": job_id,
                "mapId": map_id,
                "bucket": bucket,
                "key": key,
                "status": "FAILED",
                "error": f"Invalid filename: {error_msg}"
            })
            continue  # Skip to next file

        # Get the metadata that the frontend set when uploading
        # This includes jobId, mapId (hash), batchSize, and who uploaded it
        try:
            metadata = get_s3_metadata(bucket, key)
        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code", "Unknown")
            logging.error(
                f"Cannot process file - metadata retrieval failed: {bucket}/{key}",
                extra={"error_code": error_code, "map_name": map_name}
            )
            # Skip this file - can't track it without metadata
            records.append({
                "bucket": bucket,
                "key": key,
                "status": "FAILED",
                "error": f"Metadata retrieval failed: {error_code}"
            })
            continue

        submitted_by = metadata.get("submittedby", "system")  # S3 lowercases metadata keys
        owner_name = metadata.get("ownername")  # Display name from Cognito
        owner_username = metadata.get("ownerusername")  # Username from Cognito
        map_id = metadata.get("mapid", f"map_{uuid4().hex[:12]}")  # Hash-based ID for deduplication
        job_id = metadata.get("jobid", f"JobId-{str(uuid4())}")  # Batch ID from frontend

        # Parse batch size with error handling for corrupted metadata
        try:
            batch_size = int(metadata.get("batchsize", "1"))
        except (ValueError, TypeError):
            logging.warning(f"Invalid batchsize in metadata for {key}, defaulting to 1")
            batch_size = 1

        # Step 1: Create or get the job record
        # For batch uploads, all files share the same jobId
        # Only the first Lambda invocation actually creates it
        try:
            create_or_get_job(job_id, submitted_by, timestamp, batch_size)
        except ClientError as exc:
            message = exc.response.get("Error", {}).get("Message", str(exc))
            logging.exception("Failed to create/get job record", extra={"jobId": job_id})
            records.append({
                "jobId": job_id,
                "bucket": bucket,
                "key": key,
                "status": "FAILED",
                "error": message,
            })
            continue  # Skip this file, move to next

        # Step 2: Create the MAP entry for this specific file
        # This also handles retry logic - if the map exists and failed before,
        # we update it to QUEUED and increment the retry counter
        create_map_entry(map_id, map_name, submitted_by, owner_name, owner_username, size_bytes, timestamp, job_id)

        # Step 3: Launch the processing task
        try:
            # Try to launch ECS task (preferred method)
            ecs_launched, task_arn = launch_ecs_task(job_id, map_id, map_name, bucket, key)
            dispatched_at = iso_timestamp()  # Capture exact dispatch time

            if ecs_launched:
                # Success! Update job status to show we've dispatched it for processing
                dynamo.update_item(
                    TableName=TABLE_NAME,
                    Key={"jobId": {"S": job_id}},
                    UpdateExpression="SET #status = :status",
                    ExpressionAttributeNames={"#status": "status"},
                    ExpressionAttributeValues={
                        ":status": {"S": "DISPATCHED"}
                    },
                )

                # Update individual map status to DISPATCHED with timing metrics
                if MAPS_TABLE_NAME:
                    try:
                        # Include dispatchedAt and taskArn for timing analysis
                        update_expr = "SET #status = :status, updatedAt = :updated, dispatchedAt = :dispatched"
                        expr_values = {
                            ":status": {"S": "DISPATCHED"},
                            ":updated": {"S": dispatched_at},
                            ":dispatched": {"S": dispatched_at}
                        }
                        # Add taskArn if available
                        if task_arn:
                            update_expr += ", taskArn = :taskArn"
                            expr_values[":taskArn"] = {"S": task_arn}

                        dynamo.update_item(
                            TableName=MAPS_TABLE_NAME,
                            Key={
                                "mapId": {"S": map_id},
                                "mapName": {"S": map_name}
                            },
                            UpdateExpression=update_expr,
                            ExpressionAttributeNames={"#status": "status"},
                            ExpressionAttributeValues=expr_values
                        )
                        logging.info(f"Updated map {map_id}/{map_name} status to DISPATCHED with taskArn={task_arn}")
                    except ClientError as exc:
                        logging.exception(f"Failed to update map {map_id} to DISPATCHED", extra={"error": str(exc)})

                records.append({"jobId": job_id, "mapId": map_id, "bucket": bucket, "key": key, "status": "DISPATCHED", "taskArn": task_arn})
            else:
                # ECS launch failed - fall back to Lambda processor
                # This is a backup path in case ECS is unavailable
                logging.info(f"Falling back to Lambda processor for map {map_id} in job {job_id}")
                payload = json.dumps({
                    "jobId": job_id,
                    "mapId": map_id,
                    "bucket": bucket,
                    "key": key,
                    "project": PROJECT
                }).encode("utf-8")
                lambda_client.invoke(
                    FunctionName=S3_COPY_FUNCTION,
                    InvocationType="Event",  # Async invocation
                    Payload=payload,
                )

                # Mark job as dispatched even though we used Lambda fallback
                dynamo.update_item(
                    TableName=TABLE_NAME,
                    Key={"jobId": {"S": job_id}},
                    UpdateExpression="SET #status = :status",
                    ExpressionAttributeNames={"#status": "status"},
                    ExpressionAttributeValues={
                        ":status": {"S": "DISPATCHED"}
                    },
                )

                # Update individual map status to DISPATCHED with timing metrics
                if MAPS_TABLE_NAME:
                    try:
                        dynamo.update_item(
                            TableName=MAPS_TABLE_NAME,
                            Key={
                                "mapId": {"S": map_id},
                                "mapName": {"S": map_name}
                            },
                            UpdateExpression="SET #status = :status, updatedAt = :updated, dispatchedAt = :dispatched",
                            ExpressionAttributeNames={"#status": "status"},
                            ExpressionAttributeValues={
                                ":status": {"S": "DISPATCHED"},
                                ":updated": {"S": dispatched_at},
                                ":dispatched": {"S": dispatched_at}
                            }
                        )
                        logging.info(f"Updated map {map_id}/{map_name} status to DISPATCHED (Lambda fallback)")
                    except ClientError as exc:
                        logging.exception(f"Failed to update map {map_id} to DISPATCHED", extra={"error": str(exc)})

                records.append({"jobId": job_id, "mapId": map_id, "bucket": bucket, "key": key, "status": "DISPATCHED"})
        except ClientError as exc:
            # Something went wrong with dispatching - mark the whole job as failed
            message = exc.response.get("Error", {}).get("Message", str(exc))
            logging.exception("Failed to dispatch map", extra={"job_id": job_id, "map_id": map_id, "bucket": bucket, "key": key})
            mark_failed(job_id, message)
            records.append({
                "jobId": job_id,
                "mapId": map_id,
                "bucket": bucket,
                "key": key,
                "status": "FAILED",
                "error": message,
            })

    # Return summary of what we processed
    return {"records": records}
